# React Metaverse App

## Install

```bash
npm run build
then copy all files under build/ to root/
```
